#include "mbed.h"
#include "rtos.h"

DigitalOut led1(LED1);

enum ID {
  ID_SW2 = 0,
  ID_SW3 = 1,
  NUM_OF_SWITCHES = 2
};

PinName switches[] = {
    SW2,
    SW3
};
    

Thread *threads[NUM_OF_SWITCHES];
InterruptIn *sw[NUM_OF_SWITCHES];
uint32_t button_pressed[NUM_OF_SWITCHES];

typedef void (*callback_function)(void);

void sw2_press(void)
{
    if(threads[ID_SW2])
       threads[ID_SW2]->signal_set(0x2);
}

void sw3_press(void)
{
    if(threads[ID_SW3])
       threads[ID_SW3]->signal_set(0x3);
}
callback_function callbacks[NUM_OF_SWITCHES] =
{
    sw2_press,
    sw3_press
};

void sw2_main(void const *argument)
{
    while (true) {
        Thread::signal_wait(0x2);
        button_pressed[ID_SW2]++;
        led1 = 1;
    }
}

void sw3_main(void const *argument)
{
    while (true) {
        Thread::signal_wait(0x3);
        button_pressed[ID_SW3]++;
        led1 = 0;
    }
}

typedef void (*main_function)(void const *argument);
main_function main_func[NUM_OF_SWITCHES] = {
    sw2_main,
    sw3_main
    };
    
int main()
{
    int i;
    for(i = 0; i< NUM_OF_SWITCHES; i++) {
        threads[i] = new Thread(main_func[i]);
        sw[i] = new InterruptIn(switches[i]);
        sw[i]->fall(callbacks[i]);
        button_pressed[i] = 0;
    }
    Timer t;
    while (true) {
        Thread::wait(5000);
        t.start();
        printf("SW2 was pressed (last 5 seconds): %d %d\r\n",
            button_pressed[ID_SW2], button_pressed[ID_SW3]);
        fflush(stdout);
        t.stop();
        printf("The time taken was %f seconds\r\n", t.read());
        unsigned int *ptr = reinterpret_cast<unsigned int*>(&led1);
        int sz = sizeof(led1)/sizeof(unsigned int);
        for(i=0; i < sz; i++) {
            printf("\r\n%08X\n", ptr[i]);
        }
        fflush(stdout);
    }
}
